import React, { useState, useEffect } from 'react';
import ajax from '../Services/fetchService';
import { useLocalState } from '../util/useLocalStorage';

const AssignmentView = () => {
    const [jwt, setJwt] = useLocalState("", "jwt");
    const assignmentId = window.location.href.split("/assignments/")[1];
    const [assignment, setAssignment] = useState({
        githubUrl: "",
        branch: "",
    });

    function updateAssignment(prop, value) {
        const newAssignment = { ...assignment };
        newAssignment[prop] = value;
        setAssignment(newAssignment);
    }

    function updateRecord() {
        ajax(`/api/assignments/${assignmentId}`, "PUT", jwt, assignment).then((assignmentsData) => {
            setAssignment(assignmentsData);
          });
    }

    useEffect(() => {
        ajax(`/api/assignments/${assignmentId}`, "GET", jwt).then((assignmentsData) => {
            setAssignment(assignmentsData);
          });
      }, []);

    return (
        <div style={{ margin: "2em" }}>
            <h1>Assignment {assignmentId}</h1>
            {assignment ? (
                <>
                    <h2>Status: {assignment.status}</h2>
                    <h3>
                        GitHub URL: <input type="url" id="githubUrl" name="githubUrl" 
                                    onChange={(e) => updateAssignment("githubUrl", e.target.value)} value={assignment.githubUrl}/>
                    </h3>
                    <h3>
                        Branch: <input type="text" id="branch" name="branch"
                                onChange={(e) => updateAssignment("branch", e.target.value)} value={assignment.branch} />
                    </h3>
                    <button onClick={() => updateRecord()}>Submit Assignment</button>
                </>
            ) : (
                <></>
            )}
        </div>
    );
};

export default AssignmentView;