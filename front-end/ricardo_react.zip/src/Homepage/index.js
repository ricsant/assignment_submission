import React from 'react';

const Homepage = () => {
    return (
        <div>
         <h1>Home Page</h1>   
         <a href="/login">Clique para entrar</a>
        </div>
    );
};

export default Homepage;